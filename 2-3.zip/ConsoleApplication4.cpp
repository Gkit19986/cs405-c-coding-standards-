// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_order
	//  varaible, and its position in the declaration. It must always be directly before the variable used for input.
	// cl /EHsc /ZW ConsoleApplication4.cpp /link /SUBSYSTEM:CONSOLE <-- to compile in windows using Developer command prompt for Visual studio
	const std::string account_number = "CharlieBrown42"; //acount number 
	char user_input[20];                                 //limit of input
	char temp_user_input[200];                           //limit of imput of another variable i introduced
	std::cout << "Enter a value: ";
	std::cin >> temp_user_input;
	int len = strlen(temp_user_input);                  // used len to get the input length 
	if (len >= 20) {                                    // if statment where if the input is larger to throw " you have entered too many characters .please try again". The program will abort.
		std::cout << "You have entered too many characters. Please try again" << std::endl;
	}
	else {
		for (int i = 0; i < len; i++) {                 //else statement hsd a for loop where as long as the string length is less than 20, the user input equals the temp varibale 
			user_input[i] = temp_user_input[i];
		}
		//user_input[len] = '\0';                          // I HAD TO LOOK TO DO A LOT OF RESEARCH to make it work.  Ironically, if i 
		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
